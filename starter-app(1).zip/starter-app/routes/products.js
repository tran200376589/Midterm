var express = require('express')
var router = express.Router()

// create a link to our drink model
var productsController = require('../controllers/productsController')

// index (http://my-app.com/products)

// new (http://my-app.com/products/new)

// show (http://my-app.com/products/12345)

// edit (http://my-app.com/products/12345/edit)

// create (http://my-app.com/products)

// update (http://my-app.com/products/12345)

// delete (http://my-app.com/products/12345/delete)

// makes our file public to the application
module.exports = router;