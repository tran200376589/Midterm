var mongoose = require( 'mongoose' )

// all model classes will inherit from 
// the mongoose.Schema class
var productSchema = new mongoose.Schema({})

// make this class public
module.exports = mongoose.model( 'Product', productSchema )