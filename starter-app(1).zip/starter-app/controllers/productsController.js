var Product = require( '../models/product' )

/* VIEWS */
// Index
exports.index = function( req, res, next ) {}

// Show
exports.show = function ( req, res, next ) {}

// New
exports.new = function ( req, res ) {}

// Edit
exports.edit = function ( req, res, next ) {}

/* ACTIONS */
// Create 
exports.create = function ( req, res, next ) {}

// Update
exports.update = function ( req, res, next ) {}

// Delete
exports.delete = function ( req, res ) {}